import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# -------------------------------
# Page Configuration
# -------------------------------
st.set_page_config(page_title="COVID-19 Dashboard", layout="wide")

st.title("COVID-19 Data Analysis and Visualization Dashboard")

st.write("""
This dashboard analyzes COVID-19 data.
It provides insights into global cases, deaths, recoveries,
and trends across different countries.
""")

# -------------------------------
# Load Dataset
# -------------------------------
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

data_path = os.path.join(base_dir, "data", "country_wise_latest.csv")
time_series_path = os.path.join(base_dir, "data", "time_series_covid19_confirmed_global.csv")

data = pd.read_csv(data_path)
ts_data = pd.read_csv(time_series_path)

# -------------------------------
# Dataset Preview
# -------------------------------
st.subheader("Dataset Preview")
st.dataframe(data.head())

# -------------------------------
# Sidebar Filters
# -------------------------------
st.sidebar.header("Filters")

metric = st.sidebar.selectbox(
    "Select Metric",
    ["Confirmed", "Deaths", "Recovered", "Death Rate", "Recovery Rate", "Active"]
)

top_n = st.sidebar.slider("Select Top N Countries", 5, 20, 10)

selected_countries = st.sidebar.multiselect(
    "Select Countries for Comparison",
    options=sorted(list(data["Country/Region"].unique())),
    default=[],
    max_selections=10
)

pie_countries = st.sidebar.multiselect(
    "Select 3 or 4 Countries for Pie Chart",
    options=sorted(list(data["Country/Region"].unique())),
    default=[],
    max_selections=4
)

ma_window = st.sidebar.slider("Moving Average Window (days)", 3, 14, 5)

# -------------------------------
# Data Cleaning + Derived Columns
# -------------------------------
data.fillna(0, inplace=True)

data["Death Rate"] = np.where(
    data["Confirmed"] > 0,
    (data["Deaths"] / data["Confirmed"]) * 100,
    0
)

data["Recovery Rate"] = np.where(
    data["Confirmed"] > 0,
    (data["Recovered"] / data["Confirmed"]) * 100,
    0
)

data["Active"] = data["Confirmed"] - data["Deaths"] - data["Recovered"]

if selected_countries:
    filtered_data = data[data["Country/Region"].isin(selected_countries)]
else:
    filtered_data = data.copy()

# -------------------------------
# Global Statistics
# -------------------------------
st.subheader("Global COVID-19 Statistics")

total_cases = data["Confirmed"].sum()
total_deaths = data["Deaths"].sum()
total_recovered = data["Recovered"].sum()

col1, col2, col3 = st.columns(3)
col1.metric("Total Confirmed Cases", f"{int(total_cases):,}")
col2.metric("Total Deaths", f"{int(total_deaths):,}")
col3.metric("Total Recovered", f"{int(total_recovered):,}")

# -------------------------------
# Top Countries by Selected Metric
# -------------------------------
st.subheader(f"Top {top_n} Countries by {metric}")

top_countries = data.sort_values(by=metric, ascending=False).head(top_n)

st.dataframe(top_countries[["Country/Region", metric]])

fig1, ax1 = plt.subplots(figsize=(10, 5))
sns.barplot(
    x=metric,
    y="Country/Region",
    hue="Country/Region",
    data=top_countries,
    palette="viridis",
    legend=False,
    ax=ax1
)
ax1.set_title(f"Top {top_n} Countries by {metric}")
ax1.set_xlabel(metric)
ax1.set_ylabel("Country")
plt.tight_layout()
st.pyplot(fig1)

# -------------------------------
# Correlation Heatmap
# -------------------------------
st.subheader("Correlation Heatmap")

corr = data[["Confirmed", "Deaths", "Recovered", "Death Rate", "Recovery Rate", "Active"]].corr()

fig2, ax2 = plt.subplots(figsize=(8, 6))
sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax2)
ax2.set_title("Feature Correlation Heatmap")
plt.tight_layout()
st.pyplot(fig2)

# -------------------------------
# Moving Average Trend Chart
# -------------------------------
st.subheader("Moving Average Trend Analysis")

ts_clean = ts_data.drop(columns=["Province/State", "Country/Region", "Lat", "Long"], errors="ignore")
global_trend = ts_clean.sum()

trend = pd.DataFrame({
    "Date": pd.to_datetime(global_trend.index, errors="coerce"),
    "Confirmed": global_trend.values
})

trend = trend.dropna()
trend["Moving Average"] = trend["Confirmed"].rolling(window=ma_window).mean()

fig3, ax3 = plt.subplots(figsize=(10, 5))
ax3.plot(trend["Date"], trend["Confirmed"], label="Actual Cases")
ax3.plot(trend["Date"], trend["Moving Average"], label=f"{ma_window}-Day Moving Average")
ax3.set_title("Moving Average of Confirmed Cases")
ax3.set_xlabel("Date")
ax3.set_ylabel("Confirmed Cases")
ax3.legend()
plt.xticks(rotation=45)
plt.tight_layout()
st.pyplot(fig3)

# -------------------------------
# Pie Chart
# -------------------------------
st.subheader(f"Distribution of {metric} for Pie Chart Countries")

if len(pie_countries) == 0:
    st.info("Please select 3 or 4 countries from the sidebar for the pie chart.")
elif len(pie_countries) < 3:
    st.warning("Please select at least 3 countries for the pie chart.")
else:
    pie_data = data[data["Country/Region"].isin(pie_countries)][["Country/Region", metric]].copy()
    pie_data = pie_data[pie_data[metric] > 0]
    pie_data = pie_data.sort_values(by=metric, ascending=False)

    if pie_data.empty:
        st.warning(f"No non-zero values available for {metric}.")
    else:
        fig4, ax4 = plt.subplots(figsize=(12, 6))

        def show_pct(pct):
            return f"{pct:.1f}%" if pct >= 2 else ""

        wedges, _, autotexts = ax4.pie(
            pie_data[metric],
            labels=None,
            autopct=show_pct,
            startangle=90,
            pctdistance=0.75,
            wedgeprops=dict(width=0.45, edgecolor="white")
        )

        ax4.set_title(f"{metric} Distribution", fontsize=16, weight="bold")

        wrapped_labels = [
            country.replace(" ", "\n")
            for country in pie_data["Country/Region"]
        ]

        ax4.legend(
            wedges,
            wrapped_labels,
            title="Countries",
            loc="center left",
            bbox_to_anchor=(1.15, 0.5),
            fontsize=11,
            title_fontsize=12
        )

        for t in autotexts:
            t.set_fontsize(11)
            t.set_weight("bold")

        ax4.set_aspect("equal")
        plt.tight_layout()
        st.pyplot(fig4)

# -------------------------------
# Selected Countries Comparison
# -------------------------------
st.subheader(f"Top 10 Selected Countries Comparison by {metric}")

if len(selected_countries) == 0:
    st.info(f"Please select one or more countries from the sidebar to compare {metric.lower()}.")
else:
    chart_data = data[data["Country/Region"].isin(selected_countries)]
    chart_data = chart_data.sort_values(by=metric, ascending=False).head(10)

    fig5, ax5 = plt.subplots(figsize=(12, 6))

    sns.barplot(
        x="Country/Region",
        y=metric,
        hue="Country/Region",
        data=chart_data,
        palette="magma",
        legend=False,
        ax=ax5
    )

    ax5.set_title(f"Top 10 Selected Countries by {metric}")
    ax5.set_xlabel("Country")
    ax5.set_ylabel(metric)
    plt.xticks(rotation=30)

    for container in ax5.containers:
        try:
            ax5.bar_label(container, fmt="%.2f" if "Rate" in metric else "%.0f")
        except Exception:
            pass

    plt.tight_layout()
    st.pyplot(fig5)

# -------------------------------
# Scatter Plot: Confirmed vs Deaths
# -------------------------------
st.subheader("Confirmed Cases vs Deaths")

fig6, ax6 = plt.subplots(figsize=(8, 6))
sns.scatterplot(x="Confirmed", y="Deaths", data=data, ax=ax6)
ax6.set_title("Confirmed Cases vs Deaths")
ax6.set_xlabel("Confirmed Cases")
ax6.set_ylabel("Deaths")
plt.tight_layout()
st.pyplot(fig6)

st.write("""
This scatter plot shows the relationship between confirmed cases and deaths.
Countries with more confirmed cases generally tend to have more deaths.
""")

# -------------------------------
# Linear Regression Model
# -------------------------------
st.subheader("Linear Regression Model")

X = data[["Confirmed"]]
y = data["Deaths"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

st.success("Model trained successfully!")

# -------------------------------
# Prediction Section
# -------------------------------
st.subheader("Predict Deaths from Confirmed Cases")

default_value = 100000.0
step_value = 1000.0
warning_limit = 1000.0

user_input = st.number_input(
    "Enter Confirmed Cases for Prediction",
    min_value=0.0,
    value=default_value,
    step=step_value
)

if user_input < warning_limit:
    st.warning(
        "Please enter a more realistic confirmed cases value for better prediction. "
        "Very small values may produce unrealistic results."
    )
else:
    input_data = pd.DataFrame([[user_input]], columns=["Confirmed"])
    raw_prediction = model.predict(input_data)[0]

    predicted_deaths = max(0.0, raw_prediction)

    if predicted_deaths > user_input:
        predicted_deaths = user_input

    st.write(f"### Predicted Deaths: {round(predicted_deaths)}")

# -------------------------------
# Regression Line Plot
# -------------------------------
st.subheader("Regression Line: Confirmed Cases vs Deaths")

fig_reg, ax_reg = plt.subplots(figsize=(8, 6))

ax_reg.scatter(data["Confirmed"], data["Deaths"], alpha=0.6, label="Actual Data")

sorted_data = data.sort_values("Confirmed")
predicted_line = model.predict(sorted_data[["Confirmed"]])

ax_reg.plot(sorted_data["Confirmed"], predicted_line, color="red", label="Regression Line")

ax_reg.set_title("Confirmed Cases vs Deaths with Regression Line")
ax_reg.set_xlabel("Confirmed Cases")
ax_reg.set_ylabel("Deaths")
ax_reg.legend()

plt.tight_layout()
st.pyplot(fig_reg)

# -------------------------------
# Actual vs Predicted Plot
# -------------------------------
st.subheader("Actual vs Predicted Deaths")

y_pred = model.predict(X_test)
y_pred = np.maximum(y_pred, 0)

fig7, ax7 = plt.subplots(figsize=(8, 6))
ax7.scatter(y_test, y_pred)
ax7.set_title("Actual vs Predicted Deaths")
ax7.set_xlabel("Actual Deaths")
ax7.set_ylabel("Predicted Deaths")
plt.tight_layout()
st.pyplot(fig7)

score = model.score(X_test, y_test)
st.write(f"Model R² Score: {score:.4f}")

# -------------------------------
# Footer
# -------------------------------
st.markdown("---")
st.write("COVID-19 Data Analysis Project using Pandas, Matplotlib, Seaborn, Scikit-learn and Streamlit")